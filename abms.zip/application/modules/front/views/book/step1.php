<div class="rooms-rates">
				<div class="container">
					<h3 class="tittle"><?php echo lang('primary_contact_details')?></h3>
					
					<div class="col-sm-12">
						<div class="col-md-8 contact-left cont">
							<h4></h4>
							
						</div>

					</div>
					
				</div>
			</div>
</div>
<script>
  $(document).ready(function() {
	$("#search_div").hide();
	$("#show_search").click(function(){
			$("#search_div").animate( { "opacity": "toggle", top:"150"} , 500 );
	});
});


</script>